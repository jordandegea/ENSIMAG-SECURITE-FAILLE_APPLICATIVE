<!-- WPDM Link Template: Default Template with Download Count -->


<div class="link-btn [color]">
    <div class="media">
        <div class="pull-left">[icon]</div>
        <div class="pull-left"><strong class="ptitle">
                [title] <span style="font-weight: 400;font-style: italic">( [download_count] downloads )</span>
            </strong>

            <div style="font-size: 9pt"><strong>[download_link]</strong> <i style="margin: 4px 0 0 5px;opacity:0.5" class="fa fa-th-large"></i> [file_size]
            </div>
        </div>
    </div>
</div>
<div style="clear: both"></div>
