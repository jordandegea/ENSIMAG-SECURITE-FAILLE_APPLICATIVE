 
 
<div class="wrap metabox-holder">
 
    <div class="icon32" id="icon-error"><br></div>
<h2>Error!</h2>
<div style="font-weight:bold;border:1px solid #dd0000;padding:10px;margin:10px;background: #FFF2F2;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;">
<?php echo $error; ?>
</div>
 
</div>

 
 